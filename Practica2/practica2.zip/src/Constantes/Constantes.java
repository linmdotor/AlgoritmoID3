package Constantes;

public final class Constantes {

	public static int NEGATIVO = 0;
	public static int POSITIVO = 1;
	
	public static String DELIMITADOR= ",";
}
